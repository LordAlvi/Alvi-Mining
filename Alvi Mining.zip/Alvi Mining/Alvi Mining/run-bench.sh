cpuminer.exe -a yespower --bench --debug -t1
